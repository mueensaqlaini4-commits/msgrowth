MUEEN STORE — MSGrowth | Setup Guide (Hindi)
==============================================

IMPORTANT
- Is package mein frontend + Firestore Rules hain. Firebase project config daalne aur rules publish karne ke baad hi live database kaam karega.
- Public HTML mein Firebase web config ka apiKey aam taur par public identifier hota hai; security Firestore Rules aur Authentication se aati hai.
- Pichhle code mein agar koi third-party secret/API token client HTML mein tha, use revoke/rotate karein. Secret browser code mein kabhi na rakhein.
- Sample prices aur services ko launch se pehle verify/edit karein. Yeh site card/UPI payment automatically collect nahi karti.

A) Firebase setup
1. https://console.firebase.google.com/ kholein aur project banayein.
2. Project Overview > Add app > Web (</>) choose karein. App register karke Firebase config copy karein.
3. index.html mein firebaseConfig ke YOUR_... placeholders ko apni web app values se replace karein.
4. Build > Authentication > Get started > Sign-in method > Email/Password enable karein.
5. Authentication > Users > Add user se apna Admin email/password banayein.
6. Authentication > Users mein admin user kholein aur uska UID copy karein.
7. Build > Firestore Database > Create database karein.
8. Firestore Rules tab mein firestore.rules ka content paste karein. REPLACE_WITH_ADMIN_AUTH_UID ko apne Admin UID se replace karein, phir Publish karein.
9. Website deploy karne ke liye GitHub repo mein index.html upload karein aur Settings > Pages se deploy karein (branch main, folder /root). Firebase config actual values ke bina orders save nahi honge.

B) Rules kaise kaam karte hain
- Unauthenticated customer sirf valid order create kar sakta hai.
- Customer order list read, order edit ya delete nahi kar sakta.
- Sirf Firestore Rules mein configured Admin UID orders read kar sakta hai aur status update kar sakta hai.
- Admin UID ko public page mein daalne ki zaroorat nahi; use sirf Firestore Rules mein rakhein.
- Rules publish karna compulsory hai. Test mode / allow read, write: if true; kabhi production mein use na karein.

C) Admin panel
1. Website kholein > Admin.
2. Firebase Authentication mein banaye admin email/password se login karein.
3. Orders list aur status dropdown dikhna chahiye.
4. Login ho raha ho par orders na dikh rahe hon, to verify karein ki Firestore Rules mein UID sahi hai aur rules publish hue hain.

D) Publish / testing checklist
[ ] Firebase config updated
[ ] Email/Password sign-in enabled
[ ] Admin user created
[ ] Correct Admin UID copied into firestore.rules
[ ] Firestore Rules published
[ ] One test order submitted
[ ] Customer browser cannot read orders collection
[ ] Admin can read orders and update status
[ ] Privacy notice, business contact, actual prices and refund/delivery terms added

E) Safety
- Customer contact details sensitive hain. Admin account ka strong unique password rakhein; public/shared phone par admin login save na karein.
- Public order form spam ke liye vulnerable ho sakta hai. Launch se pehle Firebase App Check / suitable abuse controls consider karein.
- Payment QR, payment gateway, invoice, automated notifications, and order tracking are not implemented in this starter.
